﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace A22_Ex03_01
{
    public class Motorcycle : Vehicle
    {

        private int m_EngineVolume;
        private eLicenseType m_LicenseType;

        public Motorcycle()
        { 
            Wheels.Add(,) //need to check how to add number of wheels
        }

        public int EngineVolume {
            get
            { 
                return m_EngineVolume;
            }
            set
            {
                m_EngineVolume = value;
            }
        }

        public eLicenseType LicenseType {
            get
            { 
                return m_LicenseType;
            }
            set
            { 
                m_LicenseType = value;
            }
        }  
    }
}
