﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace A22_Ex03_01
{
    public class Truck : Vehicle
    {
        private bool m_IsThereContent;
        private float m_CargoCapacity;

        public Truck()
        {

        }

        public bool IsThereContent
        {
            get
            {
                return m_IsThereContent;

            }
            set
            {
                m_IsThereContent = value;
            }
        }

        public float CargoCapacity
        {
            get
            {
                return m_CargoCapacity;

            }
            set
            {
                m_CargoCapacity = value;
            }
        }
    }
}
