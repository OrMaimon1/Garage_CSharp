﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace A22_Ex03_01
{
    //temp stat need to check if every enum need a class
    public enum eVehicleState
    {
        Fixing,
        Fixed,
        Payed,

    }
    public enum eLicenseType
    {
        A,
        A2,
        AA,
        B
    }
    public enum eColor
    {
        Red,
        White,
        Black,
        Blue
    }
    public enum eFuelType
    {
        Octan98,
        Octan96,
        Octan95,
        Solar
    }
}
