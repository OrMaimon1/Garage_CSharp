﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace A22_Ex03_01
{
    public class ElectricEngine
    {
        private float m_TimeRemainOnBattery;
        private float m_MaxTimeOnBattery;

        public void Recharge()
        {

        }

    }
}
