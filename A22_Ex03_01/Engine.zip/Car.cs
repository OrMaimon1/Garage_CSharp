﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace A22_Ex03_01
{
    public class Car : Vehicle
    {
    private eColor m_Color;
    private int m_NumberOfDoors;

    public Car()
    {

    }

    public eColor MColor
    {
        get
        {
            return m_Color;
        }
        set
        {
            m_Color = value;
        }
    }

    public int NumberOfDoors
    {
        get
        {
            return m_NumberOfDoors;

        }
        set
        {
            m_NumberOfDoors = value;
        }
    }
    }
}
